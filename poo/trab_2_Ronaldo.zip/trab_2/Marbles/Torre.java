package Marbles;

import Jogo.Posicao;
import Jogo.Tabuleiro;

/**
 * Classe que herda os comportamentos da classe abstrata Pecas e determina as regras de movimento das instâncias de Torre
 */
public class Torre extends Pecas {

    public Torre (Cor cor) {
        super(cor);
    }
    /**
     * Através do polimorfismo, especifica as regras de movimentação de uma instância de Torre
     */
    public boolean movimentoValido (Tabuleiro jogo, Posicao posicao) {
        boolean valido = false;

        if (super.movimentoValido(jogo, posicao)) {
            int xAtual = this.getPosicaoAtual().getX();
            int yAtual = this.getPosicaoAtual().getY();

            int xFinal = posicao.getX();
            int yFinal = posicao.getY();

            if(xFinal == xAtual || yFinal == yAtual) {
                valido = true;
            }
        } else {
            valido = false;
        }
        
        return valido;
    }


    @Override
    public String toString() {
        String corPeca = "";

        if (this.getCor()==Cor.BRANCO) {
            corPeca = "\u265c";
        } else {
            corPeca = "\u2656";
        }

        return corPeca;
    }

}
