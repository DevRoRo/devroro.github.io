package Marbles;

public enum Cor {
    PRETO,
    BRANCO,
    VAZIO;
}
