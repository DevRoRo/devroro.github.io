package negocio;

public interface Manobra {

    public void manobrar(Empregado empregado);
    
}
