package negocio;

public class Arqueiro extends Classe {

    public Arqueiro() {
        super("Arqueiro");
    }
}
