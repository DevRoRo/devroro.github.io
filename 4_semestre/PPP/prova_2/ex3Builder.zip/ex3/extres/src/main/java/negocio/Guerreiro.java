package negocio;

public class Guerreiro extends Classe {

    public Guerreiro() {
        super("Guerreiro");
    }
}
