package negocio;

public class Humano extends Raca {

    public Humano() {
        super("Humano");
    }
}
