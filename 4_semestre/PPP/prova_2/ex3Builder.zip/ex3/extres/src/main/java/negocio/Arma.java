package negocio;

public class Arma {
    private String nome;

    public Arma (String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }
}