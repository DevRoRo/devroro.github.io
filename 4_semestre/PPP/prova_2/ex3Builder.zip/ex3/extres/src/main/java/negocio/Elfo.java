package negocio;

public class Elfo extends Raca {

    public Elfo() {
        super("Elfo");
    }
}
