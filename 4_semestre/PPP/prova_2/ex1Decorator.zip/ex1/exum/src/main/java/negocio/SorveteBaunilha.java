package negocio;

public class SorveteBaunilha extends Sorvete{

    public SorveteBaunilha () {
        this.ingredientes = "Sorvete sabor baunilha\n";
    }
}
