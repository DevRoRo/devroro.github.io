package negocio;

public abstract class Sorvete {
    public String ingredientes;

    public String build(){
      return this.ingredientes;  
    }
}
