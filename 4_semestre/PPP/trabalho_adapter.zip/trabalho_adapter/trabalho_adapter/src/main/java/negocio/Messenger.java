package negocio;

public interface Messenger {
    public void enviarMensagem(String mensagem);
}