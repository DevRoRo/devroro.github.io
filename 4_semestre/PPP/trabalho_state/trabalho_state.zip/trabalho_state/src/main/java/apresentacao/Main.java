package apresentacao;

import negocio.Maquina;

public class Main {
    public static void main(String[] args) {
        Maquina maquina = new Maquina();

        maquina.acionar();
        maquina.acionar();
        maquina.acionar();
        maquina.acionar();
        maquina.acionar();
        maquina.acionar();
        maquina.acionar();
    }
}