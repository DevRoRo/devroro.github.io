package negocio;

public interface State {

    public State trocaEstado(Maquina maquina);
}
