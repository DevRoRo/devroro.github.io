/* Não vi a necessidade de aplicar herança numa classe abstrata Assinante para subclasses pessoaFisica, pessoaJuridica, etc...
 * pois não há nenhum comportamento espefícico para nenhuma dessas classes no escopo do exercício, sua função é apenas servir
 * de sujeito a ser notificado.
 */

import java.time.LocalDateTime;

public class Assinante implements Observer {
    private String usuario;
    private int senha;

    public Assinante (String usuario, int senha) {
        this.usuario = usuario;
        this.senha = senha;
    }

    public String getUsuario() {
        return usuario;
    }
    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }
    
    public int getSenha() {
        return senha;
    }
    public void setSenha(int senha) {
        this.senha = senha;
    }
    @Override
    public void update() {
        LocalDateTime agora = LocalDateTime.now();
        System.out.println("Notificação para "+this.usuario+"\n"+agora+"Foi publicada uma nova fofoca no site.");
        
    }
}
