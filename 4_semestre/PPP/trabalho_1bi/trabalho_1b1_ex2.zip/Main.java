public class Main {
    public static void main(String[] args) {

        Site site = new Site();
        
        Assinante fulano = new Assinante("Fulano", 1235);
        Assinante ciclano = new Assinante("Ciclano", 1563);
        Assinante beltrano = new Assinante("Beltrano", 7654);

        site.addObserver(fulano);
        site.addObserver(ciclano);
        site.addObserver(beltrano);

        site.adicionarFofoca("Fulano está saindo com beltrano as escondidas");

    }
}
