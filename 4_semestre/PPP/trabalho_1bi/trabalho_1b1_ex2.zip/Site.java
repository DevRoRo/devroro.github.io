import java.util.ArrayList;
import java.util.List;

public class Site implements Subject {
    private List<String> fofocas;
    private List<Observer> listaObservers;

    public Site() {
        this.fofocas = new ArrayList<String>();
        this.listaObservers = new ArrayList<Observer>();
    }

    public List<String> getFofocas() {
        return fofocas;
    }

    public void adicionarFofoca(String fofoca) {
        this.fofocas.add(fofoca);
        notifyObservers();
    }

    @Override
    public void addObserver(Observer observer) {
        this.listaObservers.add(observer);
    }

    @Override
    public void removeObserver(int indice) {
        this.listaObservers.remove(indice);
    }

    @Override
    public void notifyObservers() {
        for (int i = 0; i < this.listaObservers.size(); i++) {
            this.listaObservers.get(i).update();
        }
    }
}
