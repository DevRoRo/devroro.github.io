package negocio;

public abstract class HtmlDocument {
    public String script;

    public String build(){
      return this.script;  
    }
}
